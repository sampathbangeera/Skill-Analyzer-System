<?php

require 'auth.php';
require 'config.php';


/* Get logged-in student ID */

$id = (int) $_SESSION['student_id'];


/* Update skill progress */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $sid = (int) $_POST['skill_id'];

    $p = max(
        0,
        min(
            100,
            (int) $_POST['progress']
        )
    );


    /* Determine progress status */

    if ($p == 100) {

        $s = 'Completed';

    } elseif ($p > 50) {

        $s = 'Practicing';

    } elseif ($p > 0) {

        $s = 'Learning';

    } else {

        $s = 'Not Started';

    }


    /* Insert or update progress */

    $q = $conn->prepare(
        "INSERT INTO skill_progress
        (
            student_id,
            skill_id,
            progress,
            status
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?
        )
        ON DUPLICATE KEY UPDATE
            progress = VALUES(progress),
            status = VALUES(status)"
    );


    $q->bind_param(
        'iiis',
        $id,
        $sid,
        $p,
        $s
    );


    $q->execute();

}


/* Get student's skills and progress */

$r = $conn->query(
    "SELECT
        s.id,
        s.skill_name,
        ss.skill_level,
        COALESCE(sp.progress, 0) AS progress,
        COALESCE(
            sp.status,
            'Not Started'
        ) AS status

     FROM student_skills ss

     JOIN skills s
        ON s.id = ss.skill_id

     LEFT JOIN skill_progress sp
        ON sp.student_id = $id
        AND sp.skill_id = s.id

     WHERE ss.student_id = $id"
);

?>

<!doctype html>

<html>

<head>

    <title>Skill Progress</title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <link
        rel="stylesheet"
        href="style.css"
    >

</head>


<body>


<div class="container py-4">


    <!-- Dashboard Button -->

    <a
        href="dashboard.php"
        class="btn btn-secondary mb-3"
    >

        ← Dashboard

    </a>


    <div class="card p-4">


        <h2>

            📈 Skill Progress

        </h2>


        <!-- Skill Progress List -->

        <?php while ($x = $r->fetch_assoc()): ?>


            <form
                method="post"
                class="border rounded p-3 mb-3"
            >


                <!-- Skill Name -->

                <h5>

                    <?php
                    echo htmlspecialchars(
                        $x['skill_name']
                    );
                    ?>

                </h5>


                <!-- Skill Level and Status -->

                <p>

                    <?php
                    echo htmlspecialchars(
                        $x['skill_level']
                    );
                    ?>

                    |

                    <?php
                    echo htmlspecialchars(
                        $x['status']
                    );
                    ?>

                </p>


                <!-- Progress Bar -->

                <div class="progress mb-2">


                    <div
                        class="progress-bar"
                        style="width:<?php echo $x['progress']; ?>%"
                    >

                        <?php
                        echo $x['progress'];
                        ?>%

                    </div>


                </div>


                <!-- Hidden Skill ID -->

                <input
                    type="hidden"
                    name="skill_id"
                    value="<?php echo $x['id']; ?>"
                >


                <!-- Progress Slider -->

                <input
                    type="range"
                    name="progress"
                    class="form-range"
                    min="0"
                    max="100"
                    value="<?php echo $x['progress']; ?>"
                >


                <!-- Update Button -->

                <button
                    type="submit"
                    class="btn btn-success btn-sm"
                >

                    Update

                </button>


            </form>


        <?php endwhile; ?>


    </div>


</div>


</body>

</html>