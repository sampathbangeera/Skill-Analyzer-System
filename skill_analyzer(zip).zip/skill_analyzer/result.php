<?php

require 'auth.php';
require 'config.php';


/* Get logged-in student ID */

$id = (int) $_SESSION['student_id'];


/* Get assessment ID */

$aid = (int) (
    $_GET['id'] ?? 0
);


/* Get assessment result */

$a = $conn->query(
    "SELECT *
     FROM assessments
     WHERE id = $aid
     AND student_id = $id"
)->fetch_assoc();


/* Check result */

if (!$a) {

    die('Result not found.');

}


/* Get assessment score */

$score = (float) $a['score'];


/* Get student's skills */

$have = [];

$r = $conn->query(
    "SELECT
        skill_id,
        skill_level
     FROM student_skills
     WHERE student_id = $id"
);


while ($x = $r->fetch_assoc()) {

    $have[$x['skill_id']] =
        $x['skill_level'];

}


/* Store role readiness */

$roles = [];


/* Get available IT roles */

$jobs = $conn->query(
    "SELECT *
     FROM jobs
     ORDER BY job_title"
);


while ($j = $jobs->fetch_assoc()) {


    /* Get required skills */

    $req = $conn->query(
        "SELECT skill_id
         FROM job_skills
         WHERE job_id = " . (int) $j['id']
    );


    $total = $req->num_rows;

    $match = 0;

    $gap = [];


    /* Compare student skills with role skills */

    while ($x = $req->fetch_assoc()) {


        if (isset($have[$x['skill_id']])) {

            $match++;

        } else {


            /* Get missing skill name */

            $s = $conn->query(
                "SELECT skill_name
                 FROM skills
                 WHERE id = " . (int) $x['skill_id']
            )->fetch_assoc();


            if ($s) {

                $gap[] =
                    $s['skill_name'];

            }

        }

    }


    /* Calculate skill match */

    $sm = $total
        ? round(
            $match / $total * 100
        )
        : 0;


    /* Calculate role readiness */

    $ready = round(
        ($sm + $score) / 2
    );


    /* Store role information */

    $roles[] = [

        'j' => $j,

        'sm' => $sm,

        'ready' => $ready,

        'gap' => $gap

    ];

}


/* Sort roles by readiness percentage */

usort(
    $roles,
    fn($x, $y) =>
        $y['ready'] <=> $x['ready']
);

?>

<!doctype html>

<html>

<head>

    <title>Assessment Result</title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <link
        rel="stylesheet"
        href="style.css"
    >

</head>


<body>


<div class="container py-4">


    <!-- Navigation -->

    <div class="d-flex justify-content-between mb-3">


        <a
            href="dashboard.php"
            class="btn btn-secondary"
        >

            ← Dashboard

        </a>


        <a
            href="assessment.php?new=1"
            class="btn btn-outline-primary"
        >

            Retake Assessment

        </a>


    </div>


    <!-- Assessment Result -->

    <div class="card p-4 mb-4">


        <h2>

            Assessment Result

        </h2>


        <div class="row text-center">


            <!-- Total Questions -->

            <div class="col-md-4">

                <h6>

                    Total

                </h6>


                <div class="stat">

                    <?php
                    echo $a['total_questions'];
                    ?>

                </div>

            </div>


            <!-- Correct Answers -->

            <div class="col-md-4">

                <h6>

                    Correct

                </h6>


                <div class="stat">

                    <?php
                    echo $a['correct_answers'];
                    ?>

                </div>

            </div>


            <!-- Score -->

            <div class="col-md-4">

                <h6>

                    Score

                </h6>


                <div class="stat">

                    <?php
                    echo $score;
                    ?>%

                </div>

            </div>


        </div>


    </div>


    <!-- IT Role Readiness -->

    <div class="card p-4">


        <h3>

            💼 IT Role Readiness

        </h3>


        <p class="text-muted">

            This is a skill-based educational indicator,
            not a guarantee of employment.

        </p>


        <!-- Role List -->

        <?php foreach ($roles as $r): ?>


            <div class="border rounded p-4 mb-3">


                <div
                    class="d-flex justify-content-between"
                >


                    <div>


                        <!-- Job Title -->

                        <h4>

                            <?php
                            echo htmlspecialchars(
                                $r['j']['job_title']
                            );
                            ?>

                        </h4>


                        <!-- Company -->

                        <p>

                            Company:

                            <?php
                            echo htmlspecialchars(
                                $r['j']['company_name']
                            );
                            ?>

                        </p>


                    </div>


                    <!-- Readiness Status -->

                    <span
                        class="badge
                        <?php
                        echo $r['ready'] >= 70
                            ? 'bg-success'
                            : 'bg-warning text-dark';
                        ?>
                        align-self-start"
                    >

                        <?php
                        echo $r['ready'] >= 70
                            ? 'Potentially Ready'
                            : 'Needs Improvement';
                        ?>

                    </span>


                </div>


                <!-- Scores -->

                <p>


                    Skill Match:

                    <strong>

                        <?php
                        echo $r['sm'];
                        ?>%

                    </strong>


                    &nbsp;


                    Assessment:

                    <strong>

                        <?php
                        echo $score;
                        ?>%

                    </strong>


                    &nbsp;


                    Role Readiness:

                    <strong>

                        <?php
                        echo $r['ready'];
                        ?>%

                    </strong>


                </p>


                <!-- Readiness Progress -->

                <div class="progress mb-2">


                    <div
                        class="progress-bar"
                        style="width:<?php echo $r['ready']; ?>%"
                    >

                        <?php
                        echo $r['ready'];
                        ?>%

                    </div>


                </div>


                <!-- Skill Gaps -->

                <?php if ($r['gap']): ?>


                    <p>


                        <strong>

                            Skills to improve:

                        </strong>


                        <?php
                        echo htmlspecialchars(
                            implode(
                                ', ',
                                $r['gap']
                            )
                        );
                        ?>


                    </p>


                <?php else: ?>


                    <p class="text-success">

                        All listed role skills
                        are in your profile.

                    </p>


                <?php endif; ?>


            </div>


        <?php endforeach; ?>


    </div>


</div>


</body>

</html>