<?php

require 'auth.php';
require 'config.php';

$id = (int)$_SESSION['student_id'];

$st = $conn->query(
    "SELECT * FROM students WHERE id=$id"
)->fetch_assoc();

$a = [];

$r = $conn->query(
    "SELECT 
        s.skill_name,
        s.category,
        ss.skill_level
     FROM student_skills ss
     JOIN skills s ON s.id = ss.skill_id
     WHERE ss.student_id = $id
     ORDER BY s.category, s.skill_name"
);

while ($x = $r->fetch_assoc()) {
    $a[] = $x;
}

$n = count($a);

$b = 0;
$i = 0;
$v = 0;

foreach ($a as $x) {

    if ($x['skill_level'] == 'Beginner') {
        $b++;
    } 
    elseif ($x['skill_level'] == 'Intermediate') {
        $i++;
    } 
    else {
        $v++;
    }
}

$read = $n
    ? round((($b * 0.4) + ($i * 0.7) + $v) / $n * 100)
    : 0;

?>

<!doctype html>

<html>

<head>

    <title>Skill Analysis</title>

    <link 
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" 
        rel="stylesheet"
    >

    <link rel="stylesheet" href="style.css">

</head>

<body>

<div class="container py-4">

    <a 
        href="dashboard.php" 
        class="btn btn-secondary mb-3"
    >
        ← Dashboard
    </a>

    <div class="card p-4">

        <h2>
            <?php echo htmlspecialchars($st['name']); ?>
            — IT Skill Analysis
        </h2>

        <div class="row g-3 mb-4">

            <!-- Total Skills -->

            <div class="col-md-3">

                <div class="card p-3">

                    <h6>Total Skills</h6>

                    <div class="stat">
                        <?php echo $n; ?>
                    </div>

                </div>

            </div>


            <!-- Beginner -->

            <div class="col-md-3">

                <div class="card p-3">

                    <h6>Beginner</h6>

                    <div class="stat">
                        <?php echo $b; ?>
                    </div>

                </div>

            </div>


            <!-- Intermediate -->

            <div class="col-md-3">

                <div class="card p-3">

                    <h6>Intermediate</h6>

                    <div class="stat">
                        <?php echo $i; ?>
                    </div>

                </div>

            </div>


            <!-- Advanced -->

            <div class="col-md-3">

                <div class="card p-3">

                    <h6>Advanced</h6>

                    <div class="stat">
                        <?php echo $v; ?>
                    </div>

                </div>

            </div>

        </div>


        <!-- Readiness -->

        <h5>
            Profile Readiness Indicator
        </h5>

        <div class="progress mb-3">

            <div 
                class="progress-bar" 
                style="width:<?php echo $read; ?>%"
            >

                <?php echo $read; ?>%

            </div>

        </div>


        <!-- Skills List -->

        <?php foreach ($a as $x): ?>

            <span 
                class="skill <?php echo strtolower($x['skill_level']); ?>"
            >

                <?php echo htmlspecialchars($x['skill_name']); ?>

                —

                <?php echo $x['skill_level']; ?>

            </span>

        <?php endforeach; ?>


        <!-- Next Step -->

        <div class="alert alert-info mt-4">

            <strong>
                Next step: Start Assessment.
            </strong>

            The questions will be selected from your IT skills 
            and your selected skill stages.

        </div>


        <!-- Assessment Button -->

        <?php if ($n): ?>

            <a 
                href="assessment.php?new=1" 
                class="btn btn-success btn-lg"
            >
                🚀 Start Assessment
            </a>

        <?php else: ?>

            <a 
                href="student.php" 
                class="btn btn-primary"
            >
                Add IT Skills
            </a>

        <?php endif; ?>

    </div>

</div>

</body>

</html>