<?php

require 'auth.php';

require 'config.php';


/* =========================================
   GET LOGGED-IN STUDENT ID
   ========================================= */

$id = (int) $_SESSION['student_id'];


/* =========================================
   GET STUDENT PROFILE
   ========================================= */

$student_query = $conn->query(
    "
    SELECT *
    FROM students
    WHERE id = $id
    "
);


if (!$student_query) {

    die(
        'Student SQL Error: '
        . $conn->error
    );

}


$student = $student_query->fetch_assoc();


if (!$student) {

    session_destroy();

    header(
        'Location: login.php'
    );

    exit;

}


/* =========================================
   GET CURRENT IT SKILLS
   ========================================= */

$skills = [];

$skill_query = $conn->query(
    "
    SELECT
        s.id,
        s.skill_name,
        s.category,
        ss.skill_level

    FROM student_skills ss

    JOIN skills s
        ON s.id = ss.skill_id

    WHERE ss.student_id = $id

    ORDER BY
        s.category,
        s.skill_name
    "
);


if ($skill_query) {

    while (
        $row =
        $skill_query->fetch_assoc()
    ) {

        $skills[] = $row;

    }

}


/* =========================================
   COUNT SKILL LEVELS
   ========================================= */

$total_skills =
    count($skills);

$beginner = 0;

$intermediate = 0;

$advanced = 0;


foreach ($skills as $skill) {

    if (
        $skill['skill_level']
        === 'Beginner'
    ) {

        $beginner++;

    }

    elseif (
        $skill['skill_level']
        === 'Intermediate'
    ) {

        $intermediate++;

    }

    elseif (
        $skill['skill_level']
        === 'Advanced'
    ) {

        $advanced++;

    }

}


/* =========================================
   GET LEARNING PROGRESS
   ========================================= */

$progress = [];

$progress_query = $conn->query(
    "
    SELECT
        s.skill_name,
        sp.progress,
        sp.status

    FROM skill_progress sp

    JOIN skills s
        ON s.id = sp.skill_id

    WHERE sp.student_id = $id

    ORDER BY
        s.skill_name
    "
);


if ($progress_query) {

    while (
        $row =
        $progress_query->fetch_assoc()
    ) {

        $progress[] = $row;

    }

}


/* =========================================
   GET LATEST ASSESSMENT
   ========================================= */

$latest_assessment = null;


$assessment_query = $conn->query(
    "
    SELECT *
    FROM assessments

    WHERE student_id = $id

    ORDER BY id DESC

    LIMIT 1
    "
);


if ($assessment_query) {

    $latest_assessment =
        $assessment_query->fetch_assoc();

}


/* =========================================
   GET NUMBER OF ASSESSMENTS
   ========================================= */

$assessment_count = 0;


$count_query = $conn->query(
    "
    SELECT COUNT(*) AS total
    FROM assessments
    WHERE student_id = $id
    "
);


if ($count_query) {

    $assessment_count =
        (int) $count_query
        ->fetch_assoc()['total'];

}


/* =========================================
   GET AVAILABLE IT JOB ROLES
   ========================================= */

$jobs = [];

$job_query = $conn->query(
    "
    SELECT *
    FROM jobs
    ORDER BY job_title
    "
);


if ($job_query) {

    while (
        $row =
        $job_query->fetch_assoc()
    ) {

        $jobs[] = $row;

    }

}


/* =========================================
   CALCULATE SIMPLE PROFILE READINESS
   ========================================= */

$profile_readiness = 0;


if ($total_skills > 0) {

    $profile_readiness = round(
        (
            ($beginner * 40) +
            ($intermediate * 70) +
            ($advanced * 100)
        )
        /
        ($total_skills * 100)
        * 100
    );

}


/* =========================================
   ASSESSMENT SCORE
   ========================================= */

$assessment_score = 0;


if ($latest_assessment) {

    $assessment_score =
        (float) $latest_assessment['score'];

}


/* =========================================
   OVERALL READINESS
   ========================================= */

$overall_readiness = 0;


if (
    $total_skills > 0 &&
    $latest_assessment
) {

    $overall_readiness = round(
        (
            $profile_readiness +
            $assessment_score
        ) / 2
    );

}

elseif ($total_skills > 0) {

    $overall_readiness =
        $profile_readiness;

}

?>

<!doctype html>

<html>

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Student Dashboard
    </title>


    <!-- Bootstrap -->

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <!-- Project CSS -->

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        .profile-box {

            background: white;

            border-radius: 16px;

            padding: 25px;

            box-shadow:
                0 5px 20px
                rgba(0, 0, 0, 0.06);

        }


        .skill-card {

            border: 1px solid #e5e7eb;

            border-radius: 12px;

            padding: 15px;

            height: 100%;

        }


        .level-beginner {

            background: #fff3cd;

            color: #664d03;

        }


        .level-intermediate {

            background: #cff4fc;

            color: #055160;

        }


        .level-advanced {

            background: #d1e7dd;

            color: #0f5132;

        }


        .level-badge {

            padding: 6px 10px;

            border-radius: 20px;

            font-size: 13px;

        }


        .progress {

            height: 20px;

            border-radius: 20px;

        }


        .dashboard-stat {

            font-size: 30px;

            font-weight: bold;

        }


        .section-title {

            font-weight: 700;

            margin-bottom: 18px;

        }


        .role-card {

            border: 1px solid #e5e7eb;

            border-radius: 12px;

            padding: 18px;

            height: 100%;

        }

    </style>

</head>


<body>


<div class="container py-4">


    <!-- =====================================
         HEADER
         ===================================== -->

    <div
        class="d-flex
               justify-content-between
               align-items-center
               mb-4"
    >


        <div>

            <h2>

                Welcome,
                <?php

                echo htmlspecialchars(
                    $student['name']
                );

                ?>

                👋

            </h2>


            <p class="text-muted mb-0">

                IT Student Job Readiness Platform

            </p>

        </div>


        <div>


            <a
                href="student.php"
                class="btn btn-outline-primary"
            >

                My Skills

            </a>


            <a
                href="logout.php"
                class="btn btn-outline-danger"
            >

                Logout

            </a>


        </div>


    </div>



    <!-- =====================================
         STUDENT PROFILE
         ===================================== -->

    <div class="profile-box mb-4">


        <h4 class="section-title">

            👤 My Profile

        </h4>


        <div class="row">


            <div class="col-md-3 mb-3">

                <strong>
                    Name
                </strong>

                <p class="mb-0">

                    <?php

                    echo htmlspecialchars(
                        $student['name']
                    );

                    ?>

                </p>

            </div>


            <div class="col-md-3 mb-3">

                <strong>
                    Email
                </strong>

                <p class="mb-0">

                    <?php

                    echo htmlspecialchars(
                        $student['email']
                    );

                    ?>

                </p>

            </div>


            <div class="col-md-3 mb-3">

                <strong>
                    Course
                </strong>

                <p class="mb-0">

                    <?php

                    echo htmlspecialchars(
                        $student['course']
                    );

                    ?>

                </p>

            </div>


            <div class="col-md-3 mb-3">

                <strong>
                    CGPA
                </strong>

                <p class="mb-0">

                    <?php

                    echo htmlspecialchars(
                        $student['cgpa']
                    );

                    ?>

                </p>

            </div>


        </div>


    </div>



    <!-- =====================================
         STATISTICS
         ===================================== -->

    <div class="row g-3 mb-4">


        <div class="col-md-3">


            <div class="card p-4">

                <h6>
                    Total IT Skills
                </h6>


                <div class="dashboard-stat">

                    <?php
                    echo $total_skills;
                    ?>

                </div>


            </div>


        </div>



        <div class="col-md-3">


            <div class="card p-4">

                <h6>
                    Intermediate
                </h6>


                <div class="dashboard-stat">

                    <?php
                    echo $intermediate;
                    ?>

                </div>


            </div>


        </div>



        <div class="col-md-3">


            <div class="card p-4">

                <h6>
                    Advanced
                </h6>


                <div class="dashboard-stat">

                    <?php
                    echo $advanced;
                    ?>

                </div>


            </div>


        </div>



        <div class="col-md-3">


            <div class="card p-4">

                <h6>
                    Assessments
                </h6>


                <div class="dashboard-stat">

                    <?php
                    echo $assessment_count;
                    ?>

                </div>


            </div>


        </div>


    </div>



    <!-- =====================================
         JOB READINESS
         ===================================== -->

    <div class="card p-4 mb-4">


        <h4 class="section-title">

            🚀 Job Readiness

        </h4>


        <?php if ($total_skills > 0): ?>


            <div class="row">


                <div class="col-md-6 mb-3">


                    <h6>

                        Skill Profile Readiness

                    </h6>


                    <div class="progress mb-2">


                        <div
                            class="progress-bar"
                            style="width:<?php echo $profile_readiness; ?>%"
                        >

                            <?php
                            echo $profile_readiness;
                            ?>%

                        </div>


                    </div>


                    <small class="text-muted">

                        Based on your selected
                        Beginner, Intermediate
                        and Advanced skills.

                    </small>


                </div>



                <div class="col-md-6 mb-3">


                    <h6>

                        Overall Readiness

                    </h6>


                    <div class="progress mb-2">


                        <div
                            class="progress-bar bg-success"
                            style="width:<?php echo $overall_readiness; ?>%"
                        >

                            <?php
                            echo $overall_readiness;
                            ?>%

                        </div>


                    </div>


                    <small class="text-muted">

                        Combines your skill profile
                        and latest assessment score.

                    </small>


                </div>


            </div>


        <?php else: ?>


            <div class="alert alert-warning">

                You have not entered your IT skills yet.

            </div>


            <a
                href="student.php"
                class="btn btn-primary"
            >

                Add My IT Skills

            </a>


        <?php endif; ?>


    </div>



    <!-- =====================================
         CURRENT IT SKILLS
         ===================================== -->

    <div class="card p-4 mb-4">


        <div
            class="d-flex
                   justify-content-between
                   align-items-center"
        >


            <h4 class="section-title mb-0">

                💻 My Current IT Skills

            </h4>


            <a
                href="student.php"
                class="btn btn-sm btn-primary"
            >

                Edit Skills

            </a>


        </div>


        <div class="row g-3 mt-2">


            <?php if ($total_skills > 0): ?>


                <?php foreach (
                    $skills
                    as $skill
                ): ?>


                    <div class="col-md-4">


                        <div class="skill-card">


                            <h5>

                                <?php

                                echo htmlspecialchars(
                                    $skill['skill_name']
                                );

                                ?>

                            </h5>


                            <p class="text-muted mb-2">

                                <?php

                                echo htmlspecialchars(
                                    $skill['category']
                                );

                                ?>

                            </p>


                            <?php

                            $level_class =
                                'level-beginner';


                            if (
                                $skill['skill_level']
                                === 'Intermediate'
                            ) {

                                $level_class =
                                    'level-intermediate';

                            }


                            if (
                                $skill['skill_level']
                                === 'Advanced'
                            ) {

                                $level_class =
                                    'level-advanced';

                            }

                            ?>


                            <span
                                class="level-badge
                                <?php
                                echo $level_class;
                                ?>"
                            >

                                <?php

                                echo htmlspecialchars(
                                    $skill['skill_level']
                                );

                                ?>

                            </span>


                        </div>


                    </div>


                <?php endforeach; ?>


            <?php else: ?>


                <div class="col-12">


                    <div class="alert alert-info">

                        No IT skills have been added yet.


                    </div>


                </div>


            <?php endif; ?>


        </div>


    </div>



    <!-- =====================================
         LEARNING PROGRESS
         ===================================== -->

    <div class="card p-4 mb-4">


        <div
            class="d-flex
                   justify-content-between
                   align-items-center"
        >


            <h4 class="section-title mb-0">

                📈 My Learning Progress

            </h4>


            <a
                href="progress.php"
                class="btn btn-sm btn-primary"
            >

                Update Progress

            </a>


        </div>


        <div class="mt-3">


            <?php if (
                count($progress) > 0
            ): ?>


                <?php foreach (
                    $progress
                    as $p
                ): ?>


                    <div class="mb-4">


                        <div
                            class="d-flex
                                   justify-content-between
                                   mb-1"
                        >


                            <strong>

                                <?php

                                echo htmlspecialchars(
                                    $p['skill_name']
                                );

                                ?>

                            </strong>


                            <span>

                                <?php
                                echo (int)
                                    $p['progress'];
                                ?>%

                            </span>


                        </div>


                        <div class="progress">


                            <div
                                class="progress-bar"
                                style="width:<?php echo (int) $p['progress']; ?>%"
                            >

                                <?php

                                echo htmlspecialchars(
                                    $p['status']
                                );

                                ?>

                            </div>


                        </div>


                    </div>


                <?php endforeach; ?>


            <?php else: ?>


                <div class="alert alert-info">

                    No learning progress has been
                    recorded yet.

                    <br><br>

                    Start tracking your IT skill
                    learning progress.

                </div>


                <a
                    href="progress.php"
                    class="btn btn-success"
                >

                    Start Learning Progress

                </a>


            <?php endif; ?>


        </div>


    </div>



    <!-- =====================================
         LATEST ASSESSMENT
         ===================================== -->

    <div class="card p-4 mb-4">


        <div
            class="d-flex
                   justify-content-between
                   align-items-center"
        >


            <h4 class="section-title mb-0">

                📝 Latest Assessment

            </h4>


            <a
                href="assessment_history.php"
                class="btn btn-sm btn-outline-primary"
            >

                Assessment History

            </a>


        </div>


        <?php if (
            $latest_assessment
        ): ?>


            <div class="row text-center mt-3">


                <div class="col-md-4">


                    <h6>
                        Total Questions
                    </h6>


                    <div class="dashboard-stat">

                        <?php

                        echo
                            $latest_assessment[
                                'total_questions'
                            ];

                        ?>

                    </div>


                </div>



                <div class="col-md-4">


                    <h6>
                        Correct Answers
                    </h6>


                    <div class="dashboard-stat">

                        <?php

                        echo
                            $latest_assessment[
                                'correct_answers'
                            ];

                        ?>

                    </div>


                </div>



                <div class="col-md-4">


                    <h6>
                        Latest Score
                    </h6>


                    <div
                        class="dashboard-stat
                               text-success"
                    >

                        <?php

                        echo
                            $latest_assessment[
                                'score'
                            ];

                        ?>%

                    </div>


                </div>


            </div>


            <div class="mt-3">


                <a
                    href="result.php?id=<?php echo (int) $latest_assessment['id']; ?>"
                    class="btn btn-primary"
                >

                    View Latest Result

                </a>


                <a
                    href="assessment.php?new=1"
                    class="btn btn-success"
                >

                    Take Assessment Again

                </a>


            </div>


        <?php else: ?>


            <div class="alert alert-info mt-3">

                You have not completed an assessment yet.

            </div>


            <?php if ($total_skills > 0): ?>


                <a
                    href="assessment.php?new=1"
                    class="btn btn-success"
                >

                    🚀 Start Assessment

                </a>


            <?php else: ?>


                <a
                    href="student.php"
                    class="btn btn-primary"
                >

                    Add Skills First

                </a>


            <?php endif; ?>


        <?php endif; ?>


    </div>



    <!-- =====================================
         JOB READINESS JOURNEY
         ===================================== -->

    <div class="card p-4 mb-4">


        <h4 class="section-title">

            🛣️ My Job Readiness Journey

        </h4>


        <div class="row g-3">


            <div class="col-md-3">


                <a
                    href="student.php"
                    class="btn btn-outline-primary
                           w-100 p-3"
                >

                    <strong>
                        1
                    </strong>

                    <br>

                    Enter Skills

                </a>


            </div>



            <div class="col-md-3">


                <a
                    href="analysis.php"
                    class="btn btn-outline-info
                           w-100 p-3"
                >

                    <strong>
                        2
                    </strong>

                    <br>

                    Analyze Skills

                </a>


            </div>



            <div class="col-md-3">


                <a
                    href="assessment.php?new=1"
                    class="btn btn-outline-success
                           w-100 p-3"
                >

                    <strong>
                        3
                    </strong>

                    <br>

                    Start Assessment

                </a>


            </div>



            <div class="col-md-3">


                <a
                    href="recommend.php"
                    class="btn btn-dark
                           w-100 p-3"
                >

                    <strong>
                        4
                    </strong>

                    <br>

                    IT Role Readiness

                </a>


            </div>


        </div>


    </div>



    <!-- =====================================
         IT JOB ROLES
         ===================================== -->

    <div class="card p-4 mb-4">


        <h4 class="section-title">

            💼 IT Job Roles

        </h4>


        <?php if (
            count($jobs) > 0
        ): ?>


            <div class="row g-3">


                <?php foreach (
                    $jobs
                    as $job
                ): ?>


                    <div class="col-md-6">


                        <div class="role-card">


                            <h5>

                                <?php

                                echo htmlspecialchars(
                                    $job['job_title']
                                );

                                ?>

                            </h5>


                            <p class="text-muted">

                                Company:

                                <?php

                                echo htmlspecialchars(
                                    $job['company_name']
                                );

                                ?>

                            </p>


                            <a
                                href="analyze.php?job_id=<?php echo (int) $job['id']; ?>"
                                class="btn btn-sm btn-primary"
                            >

                                Check Skill Gap

                            </a>


                        </div>


                    </div>


                <?php endforeach; ?>


            </div>


        <?php else: ?>


            <div class="alert alert-warning">

                No IT job roles are available yet.

            </div>


        <?php endif; ?>


    </div>



    <!-- =====================================
         FOOTER
         ===================================== -->

    <div class="text-center text-muted py-3">

        IT Student Job Readiness Platform

        <br>

        <small>

            Your profile, skills, assessments
            and learning progress are saved
            to your student account.

        </small>

    </div>


</div>


</body>

</html>