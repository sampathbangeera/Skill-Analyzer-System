<?php

/* Database details */

$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'skill_gap_db';


/* Create database connection */

$conn = new mysqli(
    $host,
    $user,
    $pass,
    $db
);


/* Check connection */

if ($conn->connect_error) {

    die(
        'Database connection failed: '
        . $conn->connect_error
    );

}


/* Set character encoding */

$conn->set_charset('utf8mb4');

?>