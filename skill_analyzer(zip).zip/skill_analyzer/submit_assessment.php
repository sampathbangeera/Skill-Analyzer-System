<?php

require 'auth.php';

require 'config.php';


/* Get logged-in student ID */

$id = (int) $_SESSION['student_id'];


/* Get assessment questions */

$ids = $_SESSION['aq'] ?? [];


/* Get submitted answers */

$ans = $_POST['answer'] ?? [];


/* Check whether assessment exists */

if (!$ids) {

    die(
        'Assessment expired. Start again.'
    );

}


/* Create assessment record */

$q = $conn->prepare(
    'INSERT INTO assessments
    (
        student_id,
        total_questions,
        correct_answers,
        score
    )
    VALUES
    (
        ?,
        ?,
        0,
        0
    )'
);


$total = count($ids);


$q->bind_param(
    'ii',
    $id,
    $total
);


$q->execute();


$aid = $q->insert_id;


/* Initialize correct answer count */

$correct = 0;


/* Prepare question query */

$get = $conn->prepare(
    'SELECT correct_option
     FROM questions
     WHERE id = ?'
);


/* Prepare answer insert query */

$ins = $conn->prepare(
    'INSERT INTO assessment_answers
    (
        assessment_id,
        question_id,
        selected_option,
        is_correct
    )
    VALUES
    (
        ?,
        ?,
        ?,
        ?
    )'
);


/* Prepare assessment question query */

$link = $conn->prepare(
    'INSERT INTO assessment_questions
    (
        assessment_id,
        question_id
    )
    VALUES
    (
        ?,
        ?
    )'
);


/* Check each question */

foreach ($ids as $qid) {


    /* Convert question ID to integer */

    $qid = (int) $qid;


    /* Get selected answer */

    $sel = strtoupper(
        $ans[$qid] ?? ''
    );


    /* Get correct answer */

    $get->bind_param(
        'i',
        $qid
    );


    $get->execute();


    $x = $get
        ->get_result()
        ->fetch_assoc();


    /* Check answer */

    $ok = (
        $x &&
        $sel === $x['correct_option']
    )
        ? 1
        : 0;


    /* Increase correct answer count */

    if ($ok) {

        $correct++;

    }


    /* Save student's answer */

    $ins->bind_param(
        'iisi',
        $aid,
        $qid,
        $sel,
        $ok
    );


    $ins->execute();


    /* Save question used in assessment */

    $link->bind_param(
        'ii',
        $aid,
        $qid
    );


    $link->execute();

}


/* Calculate score */

$score = $total
    ? round(
        $correct / $total * 100,
        2
    )
    : 0;


/* Update assessment result */

$u = $conn->prepare(
    'UPDATE assessments
     SET correct_answers = ?,
         score = ?
     WHERE id = ?'
);


$u->bind_param(
    'idi',
    $correct,
    $score,
    $aid
);


$u->execute();


/* Clear assessment questions from session */

unset(
    $_SESSION['aq']
);


/* Redirect to result page */

header(
    'Location: result.php?id=' . $aid
);

exit;

?>