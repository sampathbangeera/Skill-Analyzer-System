<?php

require 'auth.php';
require 'config.php';


/* Get skill ID */

$sid = (int) (
    $_GET['skill_id'] ?? 0
);


/* Get skill details */

$s = $conn->query(
    "SELECT *
     FROM skills
     WHERE id = $sid"
)->fetch_assoc();


/* Get learning resources */

$r = $conn->query(
    "SELECT *
     FROM learning_resources
     WHERE skill_id = $sid"
);

?>

<!doctype html>

<html>

<head>

    <title>Learning Resources</title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

</head>


<body>


<div class="container py-4">


    <!-- Dashboard Button -->

    <a
        href="dashboard.php"
        class="btn btn-secondary mb-3"
    >

        ← Dashboard

    </a>


    <div class="card p-4">


        <!-- Skill Name -->

        <h2>

            Learning

            <?php
            echo htmlspecialchars(
                $s['skill_name']
            );
            ?>

        </h2>


        <!-- Learning Resources -->

        <?php while ($x = $r->fetch_assoc()): ?>


            <div class="border rounded p-3 mb-3">


                <!-- Resource Title -->

                <h5>

                    <?php
                    echo htmlspecialchars(
                        $x['title']
                    );
                    ?>

                </h5>


                <!-- Resource Type and Level -->

                <p>

                    <?php
                    echo htmlspecialchars(
                        $x['resource_type']
                    );
                    ?>

                    |

                    <?php
                    echo htmlspecialchars(
                        $x['level']
                    );
                    ?>

                </p>


                <!-- Open Resource -->

                <a
                    target="_blank"
                    href="<?php echo htmlspecialchars($x['url']); ?>"
                    class="btn btn-primary"
                >

                    Open Resource

                </a>


            </div>


        <?php endwhile; ?>


    </div>


</div>


</body>

</html>