<?php

/* =========================================
   START SESSION
   ========================================= */

if (session_status() === PHP_SESSION_NONE) {

    session_start();

}


/* =========================================
   DATABASE CONNECTION
   ========================================= */

require 'config.php';


/* =========================================
   MESSAGE VARIABLE
   ========================================= */

$msg = '';


/* =========================================
   CHECK FORM SUBMISSION
   ========================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    /* =====================================
       GET NAME
       ===================================== */

    $name = trim(
        $_POST['name'] ?? ''
    );


    /* =====================================
       GET EMAIL
       ===================================== */

    $email = trim(
        $_POST['email'] ?? ''
    );


    /* =====================================
       GET PASSWORD
       ===================================== */

    $password =
        $_POST['password'] ?? '';


    /* =====================================
       VALIDATE NAME
       ===================================== */

    if ($name === '') {

        $msg =
            'Please enter your name.';

    }


    /* =====================================
       VALIDATE EMAIL
       ===================================== */

    elseif (
        !filter_var(
            $email,
            FILTER_VALIDATE_EMAIL
        )
    ) {

        $msg =
            'Please enter a valid email address.';

    }


    /* =====================================
       VALIDATE PASSWORD
       ===================================== */

    elseif ($password === '') {

        $msg =
            'Please enter a password.';

    }


    /* =====================================
       PASSWORD LENGTH
       ===================================== */

    elseif (
        strlen($password) < 6
    ) {

        $msg =
            'Password must contain at least 6 characters.';

    }


    /* =====================================
       PROCESS REGISTRATION
       ===================================== */

    else {


        /* =================================
           CHECK EXISTING EMAIL
           ================================= */

        $check = $conn->prepare(
            "
            SELECT id
            FROM students
            WHERE email = ?
            LIMIT 1
            "
        );


        /* Check SQL */

        if (!$check) {

            die(
                'Registration SQL Error: '
                . $conn->error
            );

        }


        /* Bind email */

        $check->bind_param(
            's',
            $email
        );


        /* Execute */

        if (!$check->execute()) {

            die(
                'Registration Check Error: '
                . $check->error
            );

        }


        /* Get result */

        $existing =
            $check
            ->get_result()
            ->fetch_assoc();


        /* Close check */

        $check->close();


        /* =================================
           EMAIL ALREADY EXISTS
           ================================= */

        if ($existing) {

            $msg =
                'This email is already registered. Please login instead.';

        }


        /* =================================
           CREATE NEW ACCOUNT
           ================================= */

        else {


            /* =================================
               HASH PASSWORD
               ================================= */

            $hashed_password =
                password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );


            /* =================================
               INSERT STUDENT
               ================================= */

            /*
             * Course and CGPA are intentionally
             * NOT collected here.
             *
             * They will be entered later
             * in student.php.
             */

            $insert = $conn->prepare(
                "
                INSERT INTO students
                (
                    name,
                    email,
                    password
                )
                VALUES
                (
                    ?,
                    ?,
                    ?
                )
                "
            );


            /* Check SQL */

            if (!$insert) {

                die(
                    'Registration SQL Error: '
                    . $conn->error
                );

            }


            /* Bind values */

            $insert->bind_param(
                'sss',
                $name,
                $email,
                $hashed_password
            );


            /* Execute */

            if ($insert->execute()) {


                /* =================================
                   GET NEW STUDENT ID
                   ================================= */

                $student_id =
                    $insert->insert_id;


                /* =================================
                   SAVE STUDENT SESSION
                   ================================= */

                $_SESSION['student_id'] =
                    (int) $student_id;


                $_SESSION['student_name'] =
                    $name;


                $_SESSION['student_email'] =
                    $email;


                /* =================================
                   CLOSE INSERT
                   ================================= */

                $insert->close();


                /* =================================
                   OPEN PROFILE PAGE
                   ================================= */

                header(
                    'Location: student.php'
                );

                exit;

            }


            /* =================================
               INSERT ERROR
               ================================= */

            else {

                $msg =
                    'Account creation failed: '
                    . $insert->error;

                $insert->close();

            }

        }

    }

}

?>


<!doctype html>

<html>

<head>


    <!-- =====================================
         PAGE SETTINGS
         ===================================== -->

    <meta charset="UTF-8">


    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >


    <title>

        Create Student Account

    </title>



    <!-- =====================================
         BOOTSTRAP
         ===================================== -->

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >



    <!-- =====================================
         PROJECT CSS
         ===================================== -->

    <link
        rel="stylesheet"
        href="style.css"
    >


</head>


<body>


<div class="container">


    <!-- =====================================
         REGISTRATION CARD
         ===================================== -->

    <div class="login card p-4">


        <!-- TITLE -->

        <h2 class="mb-2">

            Create Student Account

        </h2>


        <p class="text-muted">

            Create your account to start your
            IT job readiness journey.

        </p>



        <!-- =================================
             ERROR MESSAGE
             ================================= -->

        <?php if ($msg !== ''): ?>


            <div
                class="alert alert-danger"
            >

                <?php

                echo htmlspecialchars(
                    $msg
                );

                ?>

            </div>


        <?php endif; ?>



        <!-- =================================
             REGISTRATION FORM
             ================================= -->

        <form
            method="post"
            action="register.php"
        >


            <!-- =================================
                 NAME
                 ================================= -->

            <label
                for="name"
                class="form-label"
            >

                Full Name

            </label>


            <input
                type="text"
                id="name"
                name="name"
                class="form-control mb-3"
                placeholder="Enter your full name"
                value="<?php

                echo htmlspecialchars(
                    $_POST['name'] ?? ''
                );

                ?>"
                required
            >



            <!-- =================================
                 EMAIL
                 ================================= -->

            <label
                for="email"
                class="form-label"
            >

                Email

            </label>


            <input
                type="email"
                id="email"
                name="email"
                class="form-control mb-3"
                placeholder="Enter your email"
                value="<?php

                echo htmlspecialchars(
                    $_POST['email'] ?? ''
                );

                ?>"
                required
            >



            <!-- =================================
                 PASSWORD
                 ================================= -->

            <label
                for="password"
                class="form-label"
            >

                Password

            </label>


            <input
                type="password"
                id="password"
                name="password"
                class="form-control mb-3"
                placeholder="Create a password"
                minlength="6"
                required
            >


            <small
                class="text-muted d-block mb-3"
            >

                Password must contain at least
                6 characters.

            </small>



            <!-- =================================
                 CREATE ACCOUNT BUTTON
                 ================================= -->

            <button
                type="submit"
                class="btn btn-primary w-100"
            >

                Create Account

            </button>


        </form>



        <!-- =================================
             LOGIN LINK
             ================================= -->

        <p class="mt-3 mb-0">

            Already have an account?

            <a
                href="login.php"
            >

                Login

            </a>

        </p>


    </div>


</div>


</body>

</html>