<?php

require 'auth.php';
require 'config.php';

$id = (int)$_SESSION['student_id'];

$jid = (int)($_GET['job_id'] ?? 0);


/* --------------------------------
   Get Default Job
--------------------------------- */

if (!$jid) {

    $jobResult = $conn->query(
        "SELECT id FROM jobs LIMIT 1"
    );

    if ($jobResult && $jobResult->num_rows > 0) {

        $jobRow = $jobResult->fetch_assoc();

        $jid = (int)$jobRow['id'];

    } else {

        die("No jobs available.");

    }
}


/* --------------------------------
   Get Job Details
--------------------------------- */

$jobResult = $conn->query(
    "SELECT * FROM jobs WHERE id = $jid"
);

$job = $jobResult
    ? $jobResult->fetch_assoc()
    : null;

if (!$job) {

    die("Job not found.");

}


/* --------------------------------
   Get Student Skills
--------------------------------- */

$have = [];

$r = $conn->query(
    "SELECT 
        s.id,
        s.skill_name,
        ss.skill_level
     FROM student_skills ss
     JOIN skills s 
        ON s.id = ss.skill_id
     WHERE ss.student_id = $id"
);

if ($r) {

    while ($x = $r->fetch_assoc()) {

        $have[$x['id']] = $x;

    }

}


/* --------------------------------
   Get Required Job Skills
--------------------------------- */

$req = [];

$r = $conn->query(
    "SELECT 
        s.id,
        s.skill_name,
        js.importance
     FROM job_skills js
     JOIN skills s 
        ON s.id = js.skill_id
     WHERE js.job_id = $jid"
);

if ($r) {

    while ($x = $r->fetch_assoc()) {

        $req[] = $x;

    }

}


/* --------------------------------
   Compare Skills
--------------------------------- */

$m = [];
$g = [];

foreach ($req as $x) {

    if (isset($have[$x['id']])) {

        $m[] = $x;

    } else {

        $g[] = $x;

    }

}


/* --------------------------------
   Calculate Skill Match
--------------------------------- */

$pct = count($req)
    ? round(
        count($m) / count($req) * 100
    )
    : 0;

?>

<!doctype html>

<html>

<head>

    <title>Skill Gap Analysis</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="style.css"
    >

</head>


<body>

<div class="container py-4">


    <!-- Dashboard Button -->

    <a
        href="dashboard.php"
        class="btn btn-secondary mb-3"
    >
        ← Dashboard
    </a>


    <div class="card p-4">


        <!-- Job Information -->

        <h2>

            <?php
            echo htmlspecialchars($job['job_title']);
            ?>

            — Skill Gap

        </h2>


        <p>

            <strong>Company:</strong>

            <?php
            echo htmlspecialchars($job['company_name']);
            ?>

        </p>


        <!-- Skill Match -->

        <h5>

            Skill Match:

            <?php echo $pct; ?>%

        </h5>


        <div class="progress mb-4">

            <div
                class="progress-bar"
                style="width:<?php echo $pct; ?>%"
            >

                <?php echo $pct; ?>%

            </div>

        </div>


        <div class="row">


            <!-- Skills Student Has -->

            <div class="col-md-6">

                <h4>
                    ✓ You Have
                </h4>


                <?php if (count($m) > 0): ?>

                    <?php foreach ($m as $x): ?>

                        <span class="skill have">

                            <?php
                            echo htmlspecialchars(
                                $x['skill_name']
                            );
                            ?>

                            —

                            <?php
                            echo htmlspecialchars(
                                $have[$x['id']]['skill_level']
                            );
                            ?>

                        </span>

                    <?php endforeach; ?>

                <?php else: ?>

                    <div class="alert alert-warning">

                        You have not added any required
                        skills for this job yet.

                    </div>

                <?php endif; ?>

            </div>


            <!-- Skill Gaps -->

            <div class="col-md-6">

                <h4>
                    ✗ Skill Gaps
                </h4>


                <?php if (count($g) > 0): ?>

                    <?php foreach ($g as $x): ?>

                        <span class="skill gap">

                            <?php
                            echo htmlspecialchars(
                                $x['skill_name']
                            );
                            ?>

                            —

                            <?php
                            echo htmlspecialchars(
                                $x['importance']
                            );
                            ?>

                        </span>

                    <?php endforeach; ?>

                <?php else: ?>

                    <div class="alert alert-success">

                        🎉 You have all the required
                        skills for this role.

                    </div>

                <?php endif; ?>

            </div>

        </div>


        <hr>


        <!-- Assessment -->

        <h4>
            Ready to check your IT knowledge?
        </h4>

        <p>
            Take the skill assessment to test your
            knowledge and understand which IT roles
            match your current skills.
        </p>


        <a
            href="assessment.php?new=1"
            class="btn btn-success"
        >
            🚀 Start Skill Assessment
        </a>


    </div>

</div>


</body>

</html>