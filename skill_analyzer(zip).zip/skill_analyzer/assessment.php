<?php

require 'auth.php';
require 'config.php';


/* Get logged-in student ID */

$id = (int) $_SESSION['student_id'];


/* Skill level ranking */

$levels = [

    'Beginner' => 1,

    'Intermediate' => 2,

    'Advanced' => 3

];


/* Get student's selected skills */

$studentSkills = [];


$result = $conn->query(

    "SELECT
        s.id,
        s.skill_name,
        ss.skill_level

     FROM student_skills ss

     JOIN skills s
        ON s.id = ss.skill_id

     WHERE ss.student_id = $id"

);


if ($result) {

    while ($row = $result->fetch_assoc()) {

        $studentSkills[] = $row;

    }

}


/* Check whether skills exist */

if (!$studentSkills) {

    header(
        'Location: student.php'
    );

    exit;

}


/*
    Generate a new assessment
*/

if (
    isset($_GET['new']) ||
    empty($_SESSION['aq'])
) {


    /* Clear previous questions */

    $_SESSION['aq'] = [];


    /*
        Get 15 questions
        for EACH selected subject
    */

    foreach (
        $studentSkills as $studentSkill
    ) {


        $skillId =
            (int) $studentSkill['id'];


        $skillLevel =
            $studentSkill['skill_level'];


        /*
            Get level rank
        */

        $rank =
            $levels[$skillLevel];


        /*
            Beginner:

            Beginner questions

            Intermediate:

            Beginner +
            Intermediate

            Advanced:

            Beginner +
            Intermediate +
            Advanced
        */


        $allowedLevels = [];


        foreach (
            $levels as $level => $levelRank
        ) {

            if (
                $levelRank <= $rank
            ) {

                $allowedLevels[] =
                    "'" . $level . "'";

            }

        }


        /*
            Get 15 random questions
            for this subject
        */

        $query = "

            SELECT id

            FROM questions

            WHERE skill_id = $skillId

            AND min_level IN (
                " .
                implode(
                    ',',
                    $allowedLevels
                )
                . "
            )

            ORDER BY RAND()

            LIMIT 15

        ";


        $questions =
            $conn->query($query);


        if ($questions) {

            while (
                $question =
                $questions->fetch_assoc()
            ) {

                $_SESSION['aq'][] =
                    (int) $question['id'];

            }

        }

    }


    /*
        Remove duplicate question IDs
    */

    $_SESSION['aq'] =
        array_values(
            array_unique(
                $_SESSION['aq']
            )
        );

}


/*
    Check whether questions exist
*/

if (
    empty($_SESSION['aq'])
) {

    die(
        'No questions available for your selected skills.'
    );

}


/*
    Get question IDs
*/

$questionIds =
    implode(
        ',',
        array_map(
            'intval',
            $_SESSION['aq']
        )
    );


/*
    Get questions
*/

$query = "

    SELECT
        q.*,
        s.skill_name

    FROM questions q

    JOIN skills s
        ON s.id = q.skill_id

    WHERE q.id IN (
        $questionIds
    )

";


$result =
    $conn->query($query);


$questions = [];


if ($result) {

    while (
        $row =
        $result->fetch_assoc()
    ) {

        $questions[] =
            $row;

    }

}


/*
    Keep the same random order
    stored in the session
*/

$questionMap = [];


foreach (
    $questions as $question
) {

    $questionMap[
        $question['id']
    ] = $question;

}


$orderedQuestions = [];


foreach (
    $_SESSION['aq'] as $questionId
) {

    if (
        isset(
            $questionMap[$questionId]
        )
    ) {

        $orderedQuestions[] =
            $questionMap[$questionId];

    }

}

?>

<!doctype html>

<html>

<head>

    <title>
        IT Skill Assessment
    </title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <link
        rel="stylesheet"
        href="style.css"
    >

</head>


<body>


<div class="container py-4">


    <!-- Back Button -->

    <a
        href="analysis.php"
        class="btn btn-secondary mb-3"
    >

        ← Analysis

    </a>


    <!-- Assessment Card -->

    <div class="card p-4">


        <h2>

            IT Skill Assessment

        </h2>


        <p class="text-muted">

            You will answer

            <strong>
                15 questions for each selected subject.
            </strong>

        </p>


        <!-- Selected Subjects -->

        <div class="alert alert-info">

            <strong>
                Selected Subjects:
            </strong>


            <?php

            $subjectNames = [];


            foreach (
                $studentSkills as $skill
            ) {

                $subjectNames[] =
                    htmlspecialchars(
                        $skill['skill_name']
                    );

            }


            echo implode(
                ', ',
                $subjectNames
            );

            ?>


            <br>


            <strong>
                Total Questions:
            </strong>

            <?php

            echo count(
                $orderedQuestions
            );

            ?>

        </div>


        <!-- Assessment Form -->

        <form
            method="post"
            action="submit_assessment.php"
        >


            <?php

            foreach (
                $orderedQuestions
                as $index => $question
            ):

            ?>


                <div
                    class="card question p-4 mb-3"
                >


                    <!-- Question -->

                    <h5>

                        Q<?php
                        echo $index + 1;
                        ?>.

                        <?php

                        echo htmlspecialchars(
                            $question['question']
                        );

                        ?>

                    </h5>


                    <!-- Subject and Level -->

                    <small>

                        Subject:

                        <strong>

                            <?php

                            echo htmlspecialchars(
                                $question['skill_name']
                            );

                            ?>

                        </strong>


                        |


                        Level:

                        <strong>

                            <?php

                            echo htmlspecialchars(
                                $question['min_level']
                            );

                            ?>

                        </strong>

                    </small>


                    <hr>


                    <!-- Option A -->

                    <div
                        class="form-check mb-2"
                    >

                        <input
                            class="form-check-input"
                            type="radio"
                            required
                            name="answer[<?php
                                echo $question['id'];
                            ?>]"
                            value="A"
                        >


                        <label
                            class="form-check-label"
                        >

                            <strong>
                                A.
                            </strong>

                            <?php

                            echo htmlspecialchars(
                                $question['option_a']
                            );

                            ?>

                        </label>

                    </div>


                    <!-- Option B -->

                    <div
                        class="form-check mb-2"
                    >

                        <input
                            class="form-check-input"
                            type="radio"
                            required
                            name="answer[<?php
                                echo $question['id'];
                            ?>]"
                            value="B"
                        >


                        <label
                            class="form-check-label"
                        >

                            <strong>
                                B.
                            </strong>

                            <?php

                            echo htmlspecialchars(
                                $question['option_b']
                            );

                            ?>

                        </label>

                    </div>


                    <!-- Option C -->

                    <div
                        class="form-check mb-2"
                    >

                        <input
                            class="form-check-input"
                            type="radio"
                            required
                            name="answer[<?php
                                echo $question['id'];
                            ?>]"
                            value="C"
                        >


                        <label
                            class="form-check-label"
                        >

                            <strong>
                                C.
                            </strong>

                            <?php

                            echo htmlspecialchars(
                                $question['option_c']
                            );

                            ?>

                        </label>

                    </div>


                    <!-- Option D -->

                    <div
                        class="form-check mb-2"
                    >

                        <input
                            class="form-check-input"
                            type="radio"
                            required
                            name="answer[<?php
                                echo $question['id'];
                            ?>]"
                            value="D"
                        >


                        <label
                            class="form-check-label"
                        >

                            <strong>
                                D.
                            </strong>

                            <?php

                            echo htmlspecialchars(
                                $question['option_d']
                            );

                            ?>

                        </label>

                    </div>


                </div>


            <?php

            endforeach;

            ?>


            <!-- Submit -->

            <button
                type="submit"
                class="btn btn-success btn-lg w-100"
            >

                Submit Assessment

            </button>


        </form>


    </div>


</div>


</body>

</html>