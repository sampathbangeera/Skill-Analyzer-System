<?php

require 'auth.php';

require 'config.php';


/* Get logged-in student */

$student_id =
    (int) $_SESSION['student_id'];


/* Get student details */

$student = $conn->query(
    "
    SELECT *
    FROM students
    WHERE id = $student_id
    "
)->fetch_assoc();


/* Get assessment history */

$assessments = $conn->query(
    "
    SELECT
        id,
        total_questions,
        correct_answers,
        score,
        created_at

    FROM assessments

    WHERE student_id = $student_id

    ORDER BY id DESC
    "
);

?>

<!doctype html>

<html>

<head>

    <title>
        Assessment History
    </title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <link
        rel="stylesheet"
        href="style.css"
    >

</head>


<body>


<div class="container py-4">


    <a
        href="dashboard.php"
        class="btn btn-secondary mb-3"
    >

        ← Dashboard

    </a>


    <div class="card p-4">


        <h2>

            Assessment History

        </h2>


        <p class="text-muted">

            Student:
            <?php

            echo htmlspecialchars(
                $student['name']
            );

            ?>

        </p>


        <?php if (
            $assessments &&
            $assessments->num_rows > 0
        ): ?>


            <div class="table-responsive">


                <table
                    class="table table-bordered table-hover"
                >


                    <thead>

                        <tr>

                            <th>
                                Attempt
                            </th>

                            <th>
                                Total Questions
                            </th>

                            <th>
                                Correct
                            </th>

                            <th>
                                Score
                            </th>

                            <th>
                                Date
                            </th>

                            <th>
                                Result
                            </th>

                        </tr>

                    </thead>


                    <tbody>


                    <?php

                    $attempt = 1;

                    ?>


                    <?php while (
                        $a =
                        $assessments->fetch_assoc()
                    ): ?>


                        <tr>


                            <td>

                                <?php
                                echo $attempt;
                                ?>

                            </td>


                            <td>

                                <?php
                                echo $a[
                                    'total_questions'
                                ];
                                ?>

                            </td>


                            <td>

                                <?php
                                echo $a[
                                    'correct_answers'
                                ];
                                ?>

                            </td>


                            <td>

                                <strong>

                                    <?php
                                    echo $a['score'];
                                    ?>%

                                </strong>

                            </td>


                            <td>

                                <?php
                                echo htmlspecialchars(
                                    $a['created_at']
                                );
                                ?>

                            </td>


                            <td>

                                <a
                                    href="result.php?id=<?php echo (int) $a['id']; ?>"
                                    class="btn btn-sm btn-primary"
                                >

                                    View Result

                                </a>

                            </td>


                        </tr>


                    <?php

                    $attempt++;

                    endwhile;

                    ?>


                    </tbody>


                </table>


            </div>


        <?php else: ?>


            <div class="alert alert-info">

                You have not completed any
                assessment yet.

            </div>


        <?php endif; ?>


    </div>


</div>


</body>

</html>