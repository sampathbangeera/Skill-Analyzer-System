<?php

/* =========================================
   START SESSION
   ========================================= */

if (session_status() === PHP_SESSION_NONE) {

    session_start();

}


/* =========================================
   DATABASE CONNECTION
   ========================================= */

require 'config.php';


/* =========================================
   MESSAGE VARIABLE
   ========================================= */

$msg = '';


/* =========================================
   CHECK IF STUDENT IS ALREADY LOGGED IN
   ========================================= */

if (isset($_SESSION['student_id'])) {

    header(
        'Location: dashboard.php'
    );

    exit;

}


/* =========================================
   LOGIN FORM SUBMITTED
   ========================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    /* =====================================
       GET EMAIL
       ===================================== */

    $email = trim(
        $_POST['email'] ?? ''
    );


    /* =====================================
       GET PASSWORD
       ===================================== */

    $password =
        $_POST['password'] ?? '';


    /* =====================================
       VALIDATE EMAIL AND PASSWORD
       ===================================== */

    if ($email === '') {

        $msg =
            'Please enter your email address.';

    }

    elseif ($password === '') {

        $msg =
            'Please enter your password.';

    }

    elseif (
        !filter_var(
            $email,
            FILTER_VALIDATE_EMAIL
        )
    ) {

        $msg =
            'Please enter a valid email address.';

    }

    else {


        /* =================================
           FIND STUDENT ACCOUNT
           ================================= */

        $sql = "
            SELECT
                id,
                name,
                email,
                password,
                course,
                cgpa

            FROM students

            WHERE email = ?

            LIMIT 1
        ";


        /* Prepare SQL */

        $stmt =
            $conn->prepare($sql);


        /* Check SQL */

        if (!$stmt) {

            die(
                'Login SQL Error: '
                . $conn->error
            );

        }


        /* Bind email */

        $stmt->bind_param(
            's',
            $email
        );


        /* Execute query */

        if (!$stmt->execute()) {

            die(
                'Login Execute Error: '
                . $stmt->error
            );

        }


        /* Get query result */

        $result =
            $stmt->get_result();


        /* Get student record */

        $student =
            $result->fetch_assoc();


        /* =================================
           CHECK ACCOUNT
           ================================= */

        if (!$student) {

            $msg =
                'No account found with this email. Please create an account first.';

        }

        else {


            /* =================================
               VERIFY PASSWORD
               ================================= */

            if (
                password_verify(
                    $password,
                    $student['password']
                )
            ) {


                /* =================================
                   CREATE NEW SESSION ID
                   ================================= */

                session_regenerate_id(true);


                /* =================================
                   SAVE STUDENT ID
                   ================================= */

                $_SESSION['student_id'] =
                    (int) $student['id'];


                /* =================================
                   SAVE STUDENT NAME
                   ================================= */

                $_SESSION['student_name'] =
                    $student['name'];


                /* =================================
                   SAVE STUDENT EMAIL
                   ================================= */

                $_SESSION['student_email'] =
                    $student['email'];


                /* =================================
                   CLOSE DATABASE STATEMENT
                   ================================= */

                $stmt->close();


                /* =================================
                   OPEN DASHBOARD
                   ================================= */

                header(
                    'Location: dashboard.php'
                );

                exit;

            }

            else {

                $msg =
                    'Incorrect password. Please enter the password you used when creating your account.';

            }

        }


        /* Close statement */

        if ($stmt) {

            $stmt->close();

        }

    }

}

?>


<!doctype html>

<html>

<head>


    <!-- =====================================
         PAGE SETTINGS
         ===================================== -->

    <meta charset="UTF-8">


    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >


    <title>

        Student Login

    </title>



    <!-- =====================================
         BOOTSTRAP
         ===================================== -->

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >



    <!-- =====================================
         PROJECT CSS
         ===================================== -->

    <link
        rel="stylesheet"
        href="style.css"
    >


</head>


<body>


<div class="container">


    <!-- =====================================
         LOGIN CARD
         ===================================== -->

    <div class="login card p-4">


        <!-- TITLE -->

        <h2 class="mb-2">

            Student Login

        </h2>


        <p class="text-muted">

            Login to continue to your
            IT Student Job Readiness Platform.

        </p>



        <!-- =================================
             ERROR MESSAGE
             ================================= -->

        <?php if ($msg !== ''): ?>


            <div
                class="alert alert-danger"
            >

                <?php

                echo htmlspecialchars(
                    $msg
                );

                ?>

            </div>


        <?php endif; ?>



        <!-- =================================
             LOGIN FORM
             ================================= -->

        <form
            method="post"
            action="login.php"
        >


            <!-- =================================
                 EMAIL
                 ================================= -->

            <label
                for="email"
                class="form-label"
            >

                Email

            </label>


            <input
                type="email"
                id="email"
                name="email"
                class="form-control mb-3"
                placeholder="Enter your registered email"
                value="<?php

                echo htmlspecialchars(
                    $_POST['email'] ?? ''
                );

                ?>"
                required
            >



            <!-- =================================
                 PASSWORD
                 ================================= -->

            <label
                for="password"
                class="form-label"
            >

                Password

            </label>


            <input
                type="password"
                id="password"
                name="password"
                class="form-control mb-3"
                placeholder="Enter your password"
                required
            >



            <!-- =================================
                 LOGIN BUTTON
                 ================================= -->

            <button
                type="submit"
                class="btn btn-primary w-100"
            >

                Login

            </button>


        </form>



        <!-- =================================
             REGISTER LINK
             ================================= -->

        <p class="mt-3 mb-0">

            Don't have an account?

            <a
                href="register.php"
            >

                Create Account

            </a>

        </p>


    </div>


</div>


</body>

</html>