<?php

require 'auth.php';
require 'config.php';


/* Get logged-in student ID */

$id = (int) $_SESSION['student_id'];


/* Get student's skills */

$have = [];

$r = $conn->query(
    "SELECT skill_id
     FROM student_skills
     WHERE student_id = $id"
);


while ($x = $r->fetch_assoc()) {

    $have[$x['skill_id']] = 1;

}


/* Store role recommendations */

$out = [];


/* Get all IT roles */

$jobs = $conn->query(
    "SELECT *
     FROM jobs
     ORDER BY job_title"
);


while ($j = $jobs->fetch_assoc()) {


    /* Get required skills for this role */

    $r = $conn->query(
        "SELECT skill_id
         FROM job_skills
         WHERE job_id = " . (int) $j['id']
    );


    $tot = $r->num_rows;

    $m = 0;

    $gap = [];


    /* Compare student skills with job skills */

    while ($x = $r->fetch_assoc()) {


        if (isset($have[$x['skill_id']])) {

            $m++;

        } else {


            /* Get missing skill name */

            $s = $conn->query(
                "SELECT skill_name
                 FROM skills
                 WHERE id = " . (int) $x['skill_id']
            )->fetch_assoc();


            if ($s) {

                $gap[] = $s['skill_name'];

            }

        }

    }


    /* Store recommendation */

    $out[] = [

        'j' => $j,

        'm' => $tot
            ? round(
                $m / $tot * 100
            )
            : 0,

        'gap' => $gap

    ];

}


/* Sort roles by skill match percentage */

usort(
    $out,
    fn($a, $b) =>
        $b['m'] <=> $a['m']
);

?>

<!doctype html>

<html>

<head>

    <title>IT Role Recommendations</title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <link
        rel="stylesheet"
        href="style.css"
    >

</head>


<body>


<div class="container py-4">


    <!-- Dashboard Button -->

    <a
        href="dashboard.php"
        class="btn btn-secondary mb-3"
    >

        ← Dashboard

    </a>


    <div class="card p-4">


        <h2>

            🎯 IT Role Recommendations

        </h2>


        <!-- Role Recommendations -->

        <?php foreach ($out as $x): ?>


            <div class="border rounded p-3 mb-3">


                <!-- Job Title -->

                <h4>

                    <?php
                    echo htmlspecialchars(
                        $x['j']['job_title']
                    );
                    ?>

                </h4>


                <!-- Company -->

                <p>

                    Company:

                    <?php
                    echo htmlspecialchars(
                        $x['j']['company_name']
                    );
                    ?>

                </p>


                <!-- Skill Match -->

                <div class="progress mb-2">


                    <div
                        class="progress-bar"
                        style="width:<?php echo $x['m']; ?>%"
                    >

                        <?php
                        echo $x['m'];
                        ?>%

                    </div>


                </div>


                <!-- Skills to Improve -->

                <?php if ($x['gap']): ?>


                    <p>

                        <strong>
                            Skills to improve:
                        </strong>

                        <?php
                        echo htmlspecialchars(
                            implode(
                                ', ',
                                $x['gap']
                            )
                        );
                        ?>

                    </p>


                <?php endif; ?>


                <!-- Skill Gap Button -->

                <a
                    class="btn btn-sm btn-primary"
                    href="analyze.php?job_id=<?php echo (int) $x['j']['id']; ?>"
                >

                    View Skill Gap

                </a>


            </div>


        <?php endforeach; ?>


    </div>


</div>


</body>

</html>