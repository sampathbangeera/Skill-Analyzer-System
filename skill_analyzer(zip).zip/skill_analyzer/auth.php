<?php

/* Start session */

if (session_status() === PHP_SESSION_NONE) {

    session_start();

}


/* Check student login */

if (!isset($_SESSION['student_id'])) {

    header('Location: login.php');

    exit;

}

?>