<?php

session_start();


/* If student is already logged in */

if (isset($_SESSION['student_id'])) {

    header('Location: dashboard.php');

    exit;

}

?>

<!doctype html>

<html>

<head>

    <title>IT Job Readiness Platform</title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <link
        rel="stylesheet"
        href="style.css"
    >

</head>


<body>


<div class="container py-5">


    <!-- Hero Section -->

    <div class="hero p-5">

        <h1>

            IT Student Job Readiness Platform

        </h1>


        <p class="lead">

            Know your IT skills, take a skill-based assessment
            and understand which IT roles match your current preparation.

        </p>


        <a
            href="register.php"
            class="btn btn-light me-2"
        >

            Create Account

        </a>


        <a
            href="login.php"
            class="btn btn-outline-light"
        >

            Student Login

        </a>

    </div>


    <!-- Platform Features -->

    <div class="row g-4 mt-4">


        <!-- Skill Analysis -->

        <div class="col-md-4">

            <div class="card p-4">

                <h4>

                    1. Skill Analysis

                </h4>


                <p>

                    Choose your IT skills and
                    Beginner, Intermediate or Advanced level.

                </p>

            </div>

        </div>


        <!-- Assessment -->

        <div class="col-md-4">

            <div class="card p-4">

                <h4>

                    2. Assessment

                </h4>


                <p>

                    Answer questions based on your selected
                    IT skills and levels.

                </p>

            </div>

        </div>


        <!-- Role Readiness -->

        <div class="col-md-4">

            <div class="card p-4">

                <h4>

                    3. Role Readiness

                </h4>


                <p>

                    See your score, matching IT roles
                    and skill gaps.

                </p>

            </div>

        </div>


    </div>


</div>


</body>

</html>