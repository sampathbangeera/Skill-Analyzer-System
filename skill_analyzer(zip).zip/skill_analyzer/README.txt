IT STUDENT JOB READINESS PLATFORM

SETUP
1. Extract this folder into your XAMPP htdocs folder, e.g. D:\XAMMP\htdocs\skill_analyzer
2. Start Apache and MySQL.
3. Open http://localhost/phpmyadmin/
4. Import database.sql. It creates skill_gap_db and all required tables/data.
5. Open http://localhost/skill_analyzer/
6. Register as a student.

PROJECT FLOW
Register/Login -> Enter IT Skills -> Choose Beginner/Intermediate/Advanced -> Skill Analysis -> Start Assessment -> Skill-based questions -> Score -> IT Role Readiness -> Skill Gaps/Recommendations.

FEATURES
- Student registration/login
- IT skill profile with 3 skill levels
- Skill analysis
- Dynamic assessment based on selected skills and level
- Assessment score
- IT role readiness indicator
- Job role recommendations
- Skill gap analysis
- Progress tracking
- Learning resources
- Dashboard and retake assessment

The role-readiness percentage is an educational skill indicator, not a guarantee of employment.
