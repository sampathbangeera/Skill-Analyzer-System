<?php

/* =========================================
   AUTHENTICATION
   ========================================= */

require 'auth.php';

require 'config.php';


/* =========================================
   GET LOGGED-IN STUDENT ID
   ========================================= */

$id =
    (int) $_SESSION['student_id'];


/* =========================================
   MESSAGE
   ========================================= */

$msg = '';


/* =========================================
   SAVE PROFILE AND SKILLS
   ========================================= */

if (
    $_SERVER['REQUEST_METHOD']
    === 'POST'
) {


    /* =====================================
       GET NAME
       ===================================== */

    $name = trim(
        $_POST['name'] ?? ''
    );


    /* =====================================
       GET COURSE
       ===================================== */

    $course = trim(
        $_POST['course'] ?? ''
    );


    /* =====================================
       GET CGPA
       ===================================== */

    $cgpa =
        (float) (
            $_POST['cgpa'] ?? 0
        );


    /* =====================================
       VALIDATE PROFILE
       ===================================== */

    if ($name === '') {

        $msg =
            'Please enter your name.';

    }

    elseif ($course === '') {

        $msg =
            'Please enter your course.';

    }

    elseif (
        $cgpa <= 0 ||
        $cgpa > 10
    ) {

        $msg =
            'Please enter a valid CGPA between 0 and 10.';

    }

    else {


        /* =================================
           UPDATE STUDENT PROFILE
           ================================= */

        $profile = $conn->prepare(
            "
            UPDATE students

            SET
                name = ?,
                course = ?,
                cgpa = ?

            WHERE id = ?
            "
        );


        if (!$profile) {

            die(
                'Profile SQL Error: '
                . $conn->error
            );

        }


        $profile->bind_param(
            'ssdi',
            $name,
            $course,
            $cgpa,
            $id
        );


        if (
            !$profile->execute()
        ) {

            die(
                'Profile Update Error: '
                . $profile->error
            );

        }


        $profile->close();


        /* =================================
           DELETE OLD CURRENT SKILLS
           ================================= */

        $delete_skills =
            $conn->prepare(
                "
                DELETE FROM student_skills
                WHERE student_id = ?
                "
            );


        if (!$delete_skills) {

            die(
                'Skill Delete SQL Error: '
                . $conn->error
            );

        }


        $delete_skills->bind_param(
            'i',
            $id
        );


        $delete_skills->execute();


        $delete_skills->close();


        /* =================================
           INSERT SELECTED SKILLS
           ================================= */

        $insert_skill =
            $conn->prepare(
                "
                INSERT INTO student_skills
                (
                    student_id,
                    skill_id,
                    skill_level
                )

                VALUES
                (
                    ?,
                    ?,
                    ?
                )
                "
            );


        if (!$insert_skill) {

            die(
                'Skill Insert SQL Error: '
                . $conn->error
            );

        }


        /* Get selected skills */

        $selected_skills =
            $_POST['skills'] ?? [];


        foreach (
            $selected_skills
            as $skill_id
        ) {


            /* Convert skill ID */

            $skill_id =
                (int) $skill_id;


            /* Get skill level */

            $level =
                $_POST['level'][$skill_id]
                ?? 'Beginner';


            /* Insert */

            $insert_skill->bind_param(
                'iis',
                $id,
                $skill_id,
                $level
            );


            $insert_skill->execute();

        }


        $insert_skill->close();


        /* =================================
           UPDATE SESSION NAME
           ================================= */

        $_SESSION['student_name'] =
            $name;


        /* =================================
           GO TO DASHBOARD
           ================================= */

        header(
            'Location: dashboard.php'
        );

        exit;

    }

}


/* =========================================
   GET STUDENT PROFILE
   ========================================= */

$student_query = $conn->query(
    "
    SELECT *
    FROM students
    WHERE id = $id
    "
);


if (!$student_query) {

    die(
        'Student SQL Error: '
        . $conn->error
    );

}


$student =
    $student_query->fetch_assoc();


/* =========================================
   GET CURRENT SKILLS
   ========================================= */

$current_skills = [];


$current_query = $conn->query(
    "
    SELECT
        skill_id,
        skill_level

    FROM student_skills

    WHERE student_id = $id
    "
);


if ($current_query) {

    while (
        $row =
        $current_query->fetch_assoc()
    ) {

        $current_skills[
            $row['skill_id']
        ] =
            $row['skill_level'];

    }

}


/* =========================================
   GET ALL IT SKILLS
   ========================================= */

$skills_query = $conn->query(
    "
    SELECT *
    FROM skills
    ORDER BY
        category,
        skill_name
    "
);


if (!$skills_query) {

    die(
        'Skills SQL Error: '
        . $conn->error
    );

}

?>

<!doctype html>

<html>

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>

        Complete Student Profile

    </title>


    <!-- Bootstrap -->

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <!-- Project CSS -->

    <link
        rel="stylesheet"
        href="style.css"
    >

</head>


<body>


<div class="container py-4">


    <!-- =====================================
         TOP BUTTON
         ===================================== -->

    <a
        href="dashboard.php"
        class="btn btn-secondary mb-3"
    >

        ← Dashboard

    </a>



    <!-- =====================================
         MAIN CARD
         ===================================== -->

    <div class="card p-4">


        <h2>

            👤 Complete Your Student Profile

        </h2>


        <p class="text-muted">

            Enter your course, CGPA and current
            IT skills to continue with the
            job readiness analysis.

        </p>



        <!-- =================================
             ERROR MESSAGE
             ================================= -->

        <?php if ($msg !== ''): ?>


            <div
                class="alert alert-danger"
            >

                <?php

                echo htmlspecialchars(
                    $msg
                );

                ?>

            </div>


        <?php endif; ?>



        <!-- =================================
             FORM
             ================================= -->

        <form
            method="post"
            action="student.php"
        >



            <!-- =================================
                 BASIC PROFILE
                 ================================= -->

            <h4 class="mb-3">

                📋 Academic Details

            </h4>


            <div class="row">


                <!-- NAME -->

                <div class="col-md-6 mb-3">


                    <label
                        class="form-label"
                    >

                        Full Name

                    </label>


                    <input
                        type="text"
                        name="name"
                        class="form-control"
                        value="<?php

                        echo htmlspecialchars(
                            $student['name']
                            ?? ''
                        );

                        ?>"
                        required
                    >


                </div>



                <!-- EMAIL -->

                <div class="col-md-6 mb-3">


                    <label
                        class="form-label"
                    >

                        Email

                    </label>


                    <input
                        type="email"
                        class="form-control"
                        value="<?php

                        echo htmlspecialchars(
                            $student['email']
                            ?? ''
                        );

                        ?>"
                        readonly
                    >


                </div>



                <!-- COURSE -->

                <div class="col-md-6 mb-3">


                    <label
                        class="form-label"
                    >

                        Course

                    </label>


                    <select
                        name="course"
                        class="form-select"
                        required
                    >


                        <option
                            value=""
                        >

                            Select your course

                        </option>


                        <option
                            value="BCA"
                            <?php

                            echo (
                                ($student['course']
                                ?? '')
                                === 'BCA'
                            )
                                ? 'selected'
                                : '';

                            ?>
                        >

                            BCA

                        </option>


                        <option
                            value="B.Sc Computer Science"
                            <?php

                            echo (
                                ($student['course']
                                ?? '')
                                ===
                                'B.Sc Computer Science'
                            )
                                ? 'selected'
                                : '';

                            ?>
                        >

                            B.Sc Computer Science

                        </option>


                        <option
                            value="B.Tech Computer Science"
                            <?php

                            echo (
                                ($student['course']
                                ?? '')
                                ===
                                'B.Tech Computer Science'
                            )
                                ? 'selected'
                                : '';

                            ?>
                        >

                            B.Tech Computer Science

                        </option>


                        <option
                            value="MCA"
                            <?php

                            echo (
                                ($student['course']
                                ?? '')
                                === 'MCA'
                            )
                                ? 'selected'
                                : '';

                            ?>
                        >

                            MCA

                        </option>


                        <option
                            value="Other"
                            <?php

                            echo (
                                ($student['course']
                                ?? '')
                                === 'Other'
                            )
                                ? 'selected'
                                : '';

                            ?>
                        >

                            Other

                        </option>


                    </select>


                </div>



                <!-- CGPA -->

                <div class="col-md-6 mb-3">


                    <label
                        class="form-label"
                    >

                        CGPA

                    </label>


                    <input
                        type="number"
                        name="cgpa"
                        class="form-control"
                        step="0.01"
                        min="0.01"
                        max="10"
                        placeholder="Example: 8.3"
                        value="<?php

                        if (
                            isset(
                                $student['cgpa']
                            )
                            &&
                            $student['cgpa'] > 0
                        ) {

                            echo htmlspecialchars(
                                $student['cgpa']
                            );

                        }

                        ?>"
                        required
                    >


                    <small
                        class="text-muted"
                    >

                        Enter CGPA between
                        0 and 10.

                    </small>


                </div>


            </div>



            <hr class="my-4">



            <!-- =================================
                 IT SKILLS
                 ================================= -->

            <h4>

                💻 Select Your IT Skills

            </h4>


            <p class="text-muted">

                Select the IT skills you currently
                know and choose your skill level.

            </p>



            <div class="row">


                <?php while (
                    $skill =
                    $skills_query
                    ->fetch_assoc()
                ): ?>


                    <div
                        class="col-md-6 mb-3"
                    >


                        <div
                            class="border rounded p-3"
                        >


                            <!-- SKILL CHECKBOX -->

                            <div
                                class="form-check"
                            >


                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name="skills[]"
                                    value="<?php

                                    echo (int)
                                        $skill['id'];

                                    ?>"
                                    id="skill_<?php

                                    echo (int)
                                        $skill['id'];

                                    ?>"

                                    <?php

                                    echo isset(
                                        $current_skills[
                                            $skill['id']
                                        ]
                                    )
                                        ? 'checked'
                                        : '';

                                    ?>
                                >


                                <label
                                    class="form-check-label"
                                    for="skill_<?php

                                    echo (int)
                                        $skill['id'];

                                    ?>"
                                >


                                    <strong>

                                        <?php

                                        echo htmlspecialchars(
                                            $skill[
                                                'skill_name'
                                            ]
                                        );

                                        ?>

                                    </strong>


                                </label>


                            </div>



                            <!-- CATEGORY -->

                            <small
                                class="text-muted"
                            >

                                Category:

                                <?php

                                echo htmlspecialchars(
                                    $skill[
                                        'category'
                                    ]
                                );

                                ?>

                            </small>



                            <!-- LEVEL -->

                            <select
                                name="level[<?php

                                echo (int)
                                    $skill['id'];

                                ?>]"
                                class="form-select mt-2"
                            >


                                <option
                                    value="Beginner"

                                    <?php

                                    echo (
                                        (
                                            $current_skills[
                                                $skill['id']
                                            ]
                                            ?? ''
                                        )
                                        ===
                                        'Beginner'
                                    )
                                        ? 'selected'
                                        : '';

                                    ?>
                                >

                                    Beginner

                                </option>


                                <option
                                    value="Intermediate"

                                    <?php

                                    echo (
                                        (
                                            $current_skills[
                                                $skill['id']
                                            ]
                                            ?? ''
                                        )
                                        ===
                                        'Intermediate'
                                    )
                                        ? 'selected'
                                        : '';

                                    ?>
                                >

                                    Intermediate

                                </option>


                                <option
                                    value="Advanced"

                                    <?php

                                    echo (
                                        (
                                            $current_skills[
                                                $skill['id']
                                            ]
                                            ?? ''
                                        )
                                        ===
                                        'Advanced'
                                    )
                                        ? 'selected'
                                        : '';

                                    ?>
                                >

                                    Advanced

                                </option>


                            </select>


                        </div>


                    </div>


                <?php endwhile; ?>


            </div>



            <!-- =================================
                 SAVE BUTTON
                 ================================= -->

            <button
                type="submit"
                class="btn btn-primary btn-lg w-100 mt-3"
            >

                Save Profile & Continue

            </button>


        </form>


    </div>


</div>


</body>

</html>